# DeepSeek API代理服务

这是一个简单的API代理服务，用于保护DeepSeek API密钥不在前端暴露。

## 功能特点

- 代理DeepSeek API请求，隐藏API密钥
- 基于用户ID的请求跟踪
- 简单的请求速率限制
- CORS支持

## 安装步骤

1. 克隆或下载此代码

2. 安装依赖
   ```bash
   npm install
   ```

3. 配置环境变量
   - 复制`.env.example`为`.env`
   - 填入你的DeepSeek API密钥

4. 启动服务器
   ```bash
   npm start
   ```

## 开发模式

监听文件变化并自动重启服务器:
```bash
npm run dev
```

## 接口说明

### POST /api/proxy/deepseek

代理DeepSeek API的请求。

**请求体:**
```json
{
  "prompt": "用户提示文本",
  "user_id": "用户唯一标识符(可选)"
}
```

**成功响应:**
```json
{
  "content": "生成的回复内容",
  "status": "success"
}
```

**错误响应:**
```json
{
  "error": "错误信息",
  "status": "error"
}
```

### GET /health

健康检查端点。

**成功响应:**
```json
{
  "status": "ok"
}
```

## 部署

该服务可以部署在任何支持Node.js的服务器上，如Vercel、Render、Railway、AWS或Google Cloud。

### Vercel部署步骤

1. 安装Vercel CLI
   ```bash
   npm install -g vercel
   ```

2. 添加Vercel secrets
   ```bash
   vercel secrets add deepseek-api-key your_api_key_here
   ```

3. 创建`vercel.json`文件
   ```json
   {
     "version": 2,
     "builds": [{ "src": "server.js", "use": "@vercel/node" }],
     "routes": [{ "src": "/(.*)", "dest": "/server.js" }],
     "env": {
       "DEEPSEEK_API_KEY": "@deepseek-api-key"
     }
   }
   ```

4. 部署到Vercel
   ```bash
   vercel
   ```

## 安全提示

- 在生产环境中，限制CORS为你的扩展程序域名
- 考虑添加身份验证以增强安全性
- 定期更换API密钥
- 监控API使用情况，设置适当的速率限制 