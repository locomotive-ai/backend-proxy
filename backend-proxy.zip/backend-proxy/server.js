/**
 * DeepSeek API 代理服务器
 * 用于保护API密钥不被前端泄露
 */

const express = require('express');
const axios = require('axios');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

// 从环境变量获取API密钥
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
if (!DEEPSEEK_API_KEY) {
  console.error('错误：未设置DEEPSEEK_API_KEY环境变量');
  process.exit(1);
}

const app = express();
app.use(express.json());
app.use(cors({
  origin: '*', // 在生产环境中应该限制为特定域名
}));

// 基本的速率限制 - 可以根据用户ID或订阅级别进行更复杂的限制
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟窗口
  max: 20, // 每个IP最多20个请求
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: '已达到使用限制，请稍后再试' }
});

// 应用API限流中间件
app.use('/api/proxy/deepseek', apiLimiter);

// DeepSeek API代理端点
app.post('/api/proxy/deepseek', async (req, res) => {
  try {
    const { prompt, user_id } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: '缺少必要参数' });
    }
    
    // 记录请求（可选）
    console.log(`收到来自用户 ${user_id || 'unknown'} 的请求`);
    
    // 调用DeepSeek API
    const response = await axios.post('https://api.deepseek.com/v1/chat/completions', {
      model: 'deepseek-chat',
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 800,
      stream: false,
      top_p: 0.9,
      presence_penalty: 0.2
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
      }
    });
    
    // 返回给客户端
    return res.json({
      content: response.data.choices[0].message.content,
      status: 'success'
    });
    
  } catch (error) {
    console.error('代理请求失败:', error.message);
    
    const status = error.response?.status || 500;
    const errorMessage = error.response?.data?.error?.message || '服务器内部错误';
    
    return res.status(status).json({
      error: errorMessage,
      status: 'error'
    });
  }
});

// 健康检查端点
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
}); 